#include "msg_sgn.h"
#include <fstream>
#include <iostream>
#include "mylib.h"
#include"slist.h"
#include "sgn.h"
#include "malloc.h"
using namespace std;
// default constructor mehtods
//int msg_sgn::sgn_index=0;
msg_sgn::msg_sgn(){
    sgn();
    this->setSbit(0);
}
//constructor mehtods
msg_sgn::msg_sgn(ifstream &in, char * str){
    char c;
    if(compare_arr(str,(char*)"SG_")){
       // cout<<"so sanh dung !"<<endl;
        in.getline(str,100,' ');
        in.getline(str,100,' ');
        this->setName(str);
        in.getline(str,100,' ');
        in.getline(str,100,'|');
        this->setSbit(atoi(str));
        in.getline(str,100,'@');
        this->setLength(atoi(str));
        in.get(c);
        this->setByteOrder(c);
        in.get(c);
        this->setValType(c);
        in.getline(str,100,'(');
        in.getline(str,100,',');
        this->setFactor(atof(str));
        in.getline(str,100,')');
        this->setOffset(atoi(str));
        in.getline(str,100,'[');
        in.getline(str,100,'|');
        this->setMin(atoi(str));
        in.getline(str,100,']');
        this->setMax(atoi(str));
        in.getline(str,100,'"');
        in.getline(str,100,'"');
        this->setUnit(str);
        in.getline(str,100,' ');
        in.getline(str,100);
        this->setSyntax(str);
        this->toString();
    }

}
// contructor method with char array input
msg_sgn::msg_sgn(index_arr result){
        //index_arr result =split(str);
    /*for(int i=0;i<result.index;i++){
        cout<<result.arr[i]<<endl;
    }*/
    if(compare_arr( result.arr[0],(char*)"SG_")){
    //cout<<"signal"<<endl;
    this->setName(result.arr[1]);
    this->setSbit(atoi(result.arr[2]));
    this->setLength(atoi(result.arr[3]));
    this->setByteOrder(result.arr[4][0]);
    this->setValType(result.arr[4][1]);
    this->setFactor(atof(result.arr[5]));
    this->setMin(atoi(result.arr[7]));
    this->setMax(atoi(result.arr[8]));
    //sig.setMux(result.arr[10]);
    this->setOffset(atoi(result.arr[6]));
    if(result.index==10){
    this->setUnit("");
    this->setSyntax(result.arr[9]);
    }else{
    this->setUnit(result.arr[9]);
    this->setSyntax(result.arr[10]);
    }
    //sig.toString();
    }
}

// set methods
void msg_sgn::setSbit(int s_bit){
    this->s_bit=s_bit;
}

// get methods

int msg_sgn::getSbit(){
    return this->s_bit;
}

void msg_sgn::toString(){
    sgn::toString();
    cout<<"Start bit : "<<this->s_bit<<endl;

}
