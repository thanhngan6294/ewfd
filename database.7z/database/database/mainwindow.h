#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "mydialog.h"
#include "about.h"
#include <QTreeWidget>
#include <QBrush>
#include <QTableWidget>
QT_BEGIN_NAMESPACE
class QAction;
class QActionGroup;
class QMenu;
QT_END_NAMESPACE

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
protected:
#ifndef QT_NO_CONTEXTMENU
    void contextMenuEvent(QContextMenuEvent *event) override;
#endif // QT_NO_CONTEXTMENU

private slots:
    void newFile();
    void open();
    void save();
    void cut();
    void copy();
    void paste();
    void about();
    void aboutQt();
    void EditECU();
    void InsertLine();
    void setTable();
//    void ObjectStatus();
//    void Compare();
//    void List();
//    void Export();
//    void ResettoDefault();
//    void EditCommonAttributes();
//    void EditNetwork();
//    void ConsistencyCheck();
//    void EditNetworkNode();
//    void EditNode();
//    void ExportECUs();
//    void EditEnviromentVariable();
//    void Delete();
//    void EditNodeTxMessage();
//    void EditMessage();
//    void Remove();
//    void EditJ1587Properties();
//    void EditECUNode();
//    void EditmappedTxSignal();
//    void EditSignal();
//    void TestGenerationForSelectedNodes();
//    void DeleteWithSignals();
//    void NewSignalGroup();
//    void EditmappedSignal();
//    void EditMultiplexorSignalGroup();
//    void NewMultiplexedGroup();
    void on_actionOpen_Database_triggered();

    void on_actionSave_triggered();

    void on_actionEdit_triggered();

    void on_actionAbout_triggered();

    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui;
    MyDialog *mDialog;
    void addTreeRoot(QString name, QString description);
    void addTreeChild(QTreeWidgetItem *parent,
                          QString name, QString description);
    void createActions();
    QTableWidget* m_pTableWidget;
    QStringList m_TableHeader;
    QMenu *fileMenu;
    QMenu *editMenu;
    QMenu *helpMenu;
    QAction *newAct;
    QAction *openAct;
    QAction *saveAct;
    QAction *exitAct;
    QAction *cutAct;
    QAction *copyAct;
    QAction *pasteAct;
    QAction *aboutAct;
    QAction *aboutQtAct;
    QAction *EditECUAct;
    QAction *InsertLink;
//    QAction *ObjectStatus;
//    QAction *Compare;
//    QAction *List;
//    QAction *Export;
//    QAction *ResettoDefault;
//    QAction *EditCommonAttributes;
//    QAction *EditNetwork;
//    QAction *ConsistencyCheck;
//    QAction *EditNetworkNode;
//    QAction *EditNode;
//    QAction *ExportECUs;
//    QAction *EditEnviromentVariable;
//    QAction *Delete;
//    QAction *EditJ1587Properties;
//    QAction *EditNodeTxMessage;
//    QAction *EditMessage;
//    QAction *Remove;
//    QAction *EditECUNode;
//    QAction *EditmappedTxSignal;
//    QAction *EditSignal;
//    QAction *TestGenerationForSelectedNodes;
//    QAction *DeleteWithSignals;
//    QAction *NewSignalGroup;
//    QAction *EditmappedSignal;
//    QAction *EditMultiplexorSignalGroup;
//    QAction *NewMultiplexedGroup;
};

#endif // MAINWINDOW_H
