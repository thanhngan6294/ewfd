#include "QtCore"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "mydialog.h"
#include "about.h"
#include "QStringList"
#include <iostream>
#include <fstream>
#include<stdio.h>
#include <string>
#include "msg.h"
#include <stdlib.h>
#include "slist.h"
#include "msg_sgn.h"
#include "mylib.h"
#include <QtWidgets>
#include <QHBoxLayout>
#include <QTableWidget>
#include <QApplication>
#include <QDesktopWidget>
#include <QCoreApplication>
#include <QHeaderView>
#include <QMessageBox>
using namespace std;
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->treeWidget->setColumnCount(2);
    ui->treeWidget->setHeaderLabels(QStringList() << "Name"<< "Description");

    QStringList *listTag = new QStringList();
    listTag->append("Network nodes");
    listTag->append("Messages");
    listTag->append("Signals");
    listTag->append("Networks");
    listTag->append("Environment variables");
    for(int i=0;i<listTag->count();i++){
        addTreeRoot(listTag->at(i),"description ");
    }
    createActions();
    setTable();

    QString message = tr("A context menu is available by right-clicking");
    statusBar()->showMessage(message);

        //setWindowTitle(tr("Menus"));
        setMinimumSize(80, 80);
        resize(200, 220);
    ifstream in;
    in.open("D:/Ngan/db/New folder/database/database/can.dbc");
    slist *mess_list = loadDatabase(in);
    slist *walk = mess_list;
    while(walk){
   // addTreeChild(ui->treeWidget->itemAt(2,2),"",(QString)(((msg*)walk->data)->getName()).c_str());
     //addTreeChild(ui->treeWidget->itemAt(3), name,(QString)(((msg*)walk->data)->getName()).c_str());
    walk=walk->next;
    }
}

#ifndef QT_NO_CONTEXTMENU
void MainWindow::contextMenuEvent(QContextMenuEvent *event)
{
    QMenu menu(this);
    menu.addAction(cutAct);
    menu.addAction(copyAct);
    menu.addAction(pasteAct);
    menu.addAction(EditECUAct);
    menu.addAction(InsertLink);
    //menu.addAction("dhjd");
    menu.exec(event->globalPos());
}
#endif // QT_NO_CONTEXTMENU

void MainWindow::createActions()
{
    newAct = new QAction(tr("&New"), this);
    newAct->setShortcuts(QKeySequence::New);
    newAct->setStatusTip(tr("Create a new file"));
    //newAct->setEnabled(false);

    EditECUAct = new QAction(tr("&Edit ECU"), this);
    newAct->setStatusTip(tr("Edit ECU"));

    InsertLink = new QAction(tr("&Insert Link"), this);
    newAct->setStatusTip(tr("Insert Link"));


    openAct = new QAction(tr("&Open..."), this);
    openAct->setShortcuts(QKeySequence::Open);
    openAct->setStatusTip(tr("Open an existing file"));

    saveAct = new QAction(tr("&Save"), this);
    saveAct->setShortcuts(QKeySequence::Save);
    saveAct->setStatusTip(tr("Save the document to disk"));

    exitAct = new QAction(tr("E&xit"), this);
    exitAct->setShortcuts(QKeySequence::Quit);
    exitAct->setStatusTip(tr("Exit the application"));
    connect(exitAct, &QAction::triggered, this, &QWidget::close);

    cutAct = new QAction(tr("Cu&t"), this);
    cutAct->setShortcuts(QKeySequence::Cut);
    cutAct->setStatusTip(tr("Cut the current selection's contents to the "
                            "clipboard"));

    copyAct = new QAction(tr("&Copy"), this);
    copyAct->setShortcuts(QKeySequence::Copy);
    copyAct->setStatusTip(tr("Copy the current selection's contents to the "
                             "clipboard"));

    pasteAct = new QAction(tr("&Paste"), this);
    pasteAct->setShortcuts(QKeySequence::Paste);
    pasteAct->setStatusTip(tr("Paste the clipboard's contents into the current "
                              "selection"));

    aboutAct = new QAction(tr("&About"), this);
    aboutAct->setStatusTip(tr("Show the application's About box"));

    aboutQtAct = new QAction(tr("About &Qt"), this);
    aboutQtAct->setStatusTip(tr("Show the Qt library's About box"));
    connect(aboutQtAct, &QAction::triggered, qApp, &QApplication::aboutQt);
}

void MainWindow::setTable()
{
    m_pTableWidget = new QTableWidget;
    ui->m_pTableWidget->setRowCount(10);
    ui->m_pTableWidget->setColumnCount(4);
    m_TableHeader<<"Name"<<"Protocol"<<"Comment"<<"Bus Type";
    ui->m_pTableWidget->setHorizontalHeaderLabels(m_TableHeader);
    ui->m_pTableWidget->verticalHeader()->setVisible(false);
    ui->m_pTableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->m_pTableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->m_pTableWidget->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->m_pTableWidget->setShowGrid(false);
    //m_pTableWidget->setStyleSheet("QTableView {selection-background-color: red;}");
    ui->m_pTableWidget->setGeometry(QApplication::desktop()->screenGeometry());

    //insert data
    //m_pTableWidget->setItem(0, 1, new QTableWidgetItem("Hello"));

//   connect( m_pTableWidget, SIGNAL( cellDoubleClicked (int, int) ),
//    this, SLOT( cellSelected( int, int ) ) );
}


MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionOpen_Database_triggered()
{
    MyDialog mDialog;
    mDialog.setModal(false);
    mDialog.exec();
    mDialog.show();
}

void MainWindow::on_actionSave_triggered()
{
    mDialog = new MyDialog(this);
    mDialog->show();
}

void MainWindow::on_actionEdit_triggered()
{
    MyDialog mDialog;
    mDialog.setModal(true);
    mDialog.exec();
}

void MainWindow::on_actionAbout_triggered()
{
    About mAbout;
    mAbout.setModal(true);
    mAbout.exec();
}
void MainWindow::addTreeRoot(QString name, QString description)
{
    // QTreeWidgetItem(QTreeWidget * parent, int type = Type)
    QTreeWidgetItem *treeItem = new QTreeWidgetItem(ui->treeWidget);

    // QTreeWidgetItem::setText(int column, const QString & text)
    treeItem->setIcon(0, QIcon(":icon/icon/black.png"));
   // m_publicIconMap[QStringLiteral("treeItem_Project")] =QIcon(QStringLiteral(":/treeItemIcon/res_treeItemIcon/Project.png"));
    treeItem->setText(0, name);
    treeItem->setText(1, description);
    //treeItem->setExpanded(true);

}

void MainWindow::addTreeChild(QTreeWidgetItem *parent,
                  QString name, QString description)
{
    // QTreeWidgetItem(QTreeWidget * parent, int type = Type)
    QTreeWidgetItem *treeItem = new QTreeWidgetItem();

    // QTreeWidgetItem::setText(int column, const QString & text)
    treeItem->setIcon(0, QIcon(":/icon/black.png"));
    treeItem->setText(0, name);
    treeItem->setText(1, description);

    // QTreeWidgetItem::addChild(QTreeWidgetItem * child)
    parent->addChild(treeItem);
}
void MainWindow::on_pushButton_clicked()
{
    QBrush brush_red(Qt::red);
    ui->treeWidget->currentItem()->setBackground(0, brush_red);
}
