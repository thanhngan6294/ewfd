#include "mylib.h"
#include <malloc.h>
#include "msg.h"
#include "msg_sgn.h"
using namespace std;
extern bool compare_arr(char *str_1 , char *str_2)
{
    if(strlen(str_1)==strlen(str_2)){
        for(unsigned int i=0;i<strlen(str_1);i++){
        if(str_1[i]!=str_2[i]) return false;
        }
        return true;
    }
    else{
    return false;
    }

}
index_arr split(char str[])
{
        int index = 0;
        //int i;
        char **b = (char **)malloc(100*sizeof(char));
        char *p;
        p = strtok(str, "|,[]()\"@: "); //cat chuoi bang cac ky tu ,. va space
        while(p != NULL)
        {
                b[index] = p;
                index++;
                p = strtok(NULL, "|,[]()\"@: "); //cat chuoi tu vi tri dung lai truoc do
        }
        for(int i=0; i<index;i++){

        }
       index_arr result;
       result.arr=b;
       result.index=index;
        return result ;
}
void output(void *data){
    msg * m_msg= (msg*)data;
    m_msg->toString();
    }
void out_signal(void *data){
    sgn * m_sgn= (sgn*)data;
    m_sgn->toString();
    }
void show_sig(void *data){
    msg_sgn *sig =(msg_sgn*)data;
    sig->toString();
}
void saveFile_signal(ofstream &out,void *data){
    msg_sgn * m_msg_sgn= (msg_sgn*)data;
    out<<" SG_ "<<m_msg_sgn->getName().c_str()<<" : "<<m_msg_sgn->getSbit()<<"|"<<m_msg_sgn->getLength()<<"@"
        <<m_msg_sgn->getByOrder()<<m_msg_sgn->getValType()<<" ("<<m_msg_sgn->getFactor()<<","<<m_msg_sgn->getOffset()<<") ["
        <<m_msg_sgn->getMin()<<"|"<<m_msg_sgn->getMax()<<"]"<<" \""<<m_msg_sgn->getUnit().c_str()<<"\" "<<m_msg_sgn->getSyntax().c_str()<<endl;
}
void saveFile(ofstream &out,void *data){
    msg * m_msg= (msg*)data;
    out<<"BO_ "<<m_msg->getId()<<" "<<m_msg->getName().c_str()<<" "<<m_msg->getDLC()<<" "<<m_msg->getSyn().c_str()<<endl;
    slistSaveFile(m_msg->getSgnList(), out,saveFile_signal);
}

slist * loadDatabase(ifstream &in){
    slist *msg_list=NULL;
    slist *signal_list=NULL;
    char str[1000];
    index_arr result ;
    int check=0;

    while(!in.eof()){
                // if check==1 , pass away the block
                if(check==0)
                {
                in.getline(str,1000);
                cout<<"str = "<<str<<endl;
                result = split(str);
                }
                if((result.index>0)){
                if(compare_arr(result.arr[0],(char *)"BO_")){
                    // add new message
                    msg *mess = new msg(result);
                    mess->toString();
                    // create a linkedlist for saving all signals of above message
                    slist *sgn_list =NULL;
                    // read the next line to keep on processing
                    in.getline(str,1000);
                    result = split(str);
                    //set check=1 so the program will not read the next line in the following loop
                    check=1;
                    // check to make sure that result.arr[0] exists
                    if((result.index>0))
                       {
                        while(compare_arr(result.arr[0],(char *)"SG_"))
                            {
                                // create a new signal
                                msg_sgn *sig = new msg_sgn(result);
                                sig->toString();
                                // add above signal to signal list of messaged signal
                                sgn_list=slist_append(sgn_list,(void *)sig);
                                // add signal list
                                sgn *signal = static_cast<sgn*>(sig);
                                if(!slist_check_item_exist(signal_list,(void*)signal,compare_signal))
                                    signal_list=slist_append(signal_list,(void*)signal);
                                // read the next line
                                in.getline(str,1000);
                                result = split(str);
                                if(result.index==0) break;
                            }
                       }
                        if(sgn_list)
                        {
                            mess->setSgnList(sgn_list);

                        }else{
                        mess->setSgnList(NULL);
                        }
                        msg_list= slist_append(msg_list,(void *)mess);
                        //out_put_list_data(msg_list,output);
                }
                }
                else {check=0;}
    }
    cout<<"signal list signal list signal list signal list signal list : "<<endl;
    out_put_list_data(signal_list,out_signal);
    return msg_list;
}

bool id_compare(void * data1, void * data2){
    uint64_t id = (int) data1;
    msg *walk = (msg*) data2;
    cout<<"id="<<id<<endl;
    cout<<"walk->id : "<<walk->getId()<<endl;
    if(id==walk->getId()){
    return true;
    }else{
    return false;
    }
}
void release_msg(void *data){
    msg * message = (msg*)data;
    delete message;
}
bool compare_signal(void * sig1,void * sig2){
    sgn * signal_1= (sgn*)sig1;
    sgn * signal_2= (sgn*)sig2;
    if(strcmp(signal_1->getName().c_str(),signal_2->getName().c_str())) return false;
    if(signal_1->getLength()!=signal_2->getLength()) return false;
    if(signal_1->getByOrder()!=signal_2->getByOrder()) return false;
    if(signal_1->getValType()!=signal_2->getValType()) return false;
    if(signal_1->getOffset()!=signal_2->getOffset()) return false;
    if(signal_1->getFactor()!=signal_2->getFactor()) return false;
    cout<<"signal da ton tai !"<<endl;
    return true;
}

