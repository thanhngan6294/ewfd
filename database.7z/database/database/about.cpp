#include "about.h"
#include "ui_about.h"

About::About(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::About)
{
    ui->setupUi(this);
    QPixmap pixmap("F:/FPT/db/database/about.jpg");
    ui->label ->setPixmap(pixmap);
}

About::~About()
{
    delete ui;
}
