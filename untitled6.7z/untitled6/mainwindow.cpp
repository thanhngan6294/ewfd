#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QHBoxLayout>
#include "QtWidgets"
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QWidget *mainlayout = new QWidget(this);

        listwidget = new QListWidget(this);
        listwidget->addItem(tr("Message"));
        listwidget->addItem(tr("Signal"));
        //listwidget->addItem(tr("tablewidget3"));



        tablewidget1 = new QTableWidget(10, 8, 0);
        m1_TableHeader<<"Name"<<"ID"<<"ID-Format"<<"DLC[Byte]"<<"Tx Method"<<"Cycle Time"<<"Transmitter"<<"Comment";
        tablewidget1->setHorizontalHeaderLabels(m1_TableHeader);
        tablewidget2 = new QTableWidget(10, 12, 0);
        m2_TableHeader<<"Name"<<"Length[Bit]"<<"Byte Order"<<"Value Type"<<"Initial Value"<<"Factor"<<"Offset"<<"Minimum"<<"Maximum"<<"Unit"<<"Value Table"<<"Comment";
        tablewidget2->setHorizontalHeaderLabels(m2_TableHeader);
        //tablewidget3 = new QTableWidget(8, 8, 0);
        //m_TableHeader<<"Name"<<"Protocol"<<"Comment"<<"Bus Type";
        tablewidget1->setShowGrid(false);
        tablewidget2->setShowGrid(false);
        //tablewidget3->setShowGrid(false);
        tablewidget1->verticalHeader()->setVisible(false);
        tablewidget2->verticalHeader()->setVisible(false);
        //tablewidget3->verticalHeader()->setVisible(false);


        stackedwidget = new QStackedWidget(this);
        stackedwidget->addWidget(tablewidget1);
        stackedwidget->addWidget(tablewidget2);
        //stackedwidget->addWidget(tablewidget3);


        QHBoxLayout *h_layout = new QHBoxLayout(this);
        h_layout->addWidget(listwidget);
        h_layout->addWidget(stackedwidget);
        h_layout->setStretchFactor(listwidget, 2);
        h_layout->setStretchFactor(stackedwidget, 7);

        mainlayout->setLayout(h_layout);
        setCentralWidget(mainlayout);
        //setLayout(h_layout);
        //setCentralWidget(h_layout);


        setWindowTitle(tr("QStackedWidget Test"));
        //setFixedSize(950, 300);


        connect(listwidget, SIGNAL(currentRowChanged(int)), stackedwidget,  SLOT(setCurrentIndex(int)));

}

MainWindow::~MainWindow()
{
    delete ui;
}
