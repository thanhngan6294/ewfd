#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QDialog>
#include<QListWidget>
#include<QStackedWidget>
#include<QTableWidget>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    QListWidget *listwidget;
    QStackedWidget *stackedwidget;
    QTableWidget *tablewidget1;
    QTableWidget *tablewidget2;
    QTableWidget *tablewidget3;
    QStringList m1_TableHeader;
    QStringList m2_TableHeader;
};

#endif // MAINWINDOW_H
